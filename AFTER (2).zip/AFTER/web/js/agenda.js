/* 
Autor:Escobedo Gonzalez Emmanuel
Empresa: E-DDIT
Fecha:21/03/2023
Descripcion: 
  -  Dos constructores, uno con seis parámetros y otro con cinco.
  -  Métodos "getter" y "setter" para cada propiedad de la clase, que permiten acceder
     y establecer los valores de las mismas.
  - El método toString(), que devuelve una cadena de caracteres que representa el contenido
    del objeto de la clase Agenda.
  - También se definen seis propiedades (variables) de la clase, incluyendo idAgenda, 
    materia, actiTitulo, actiDes, fechaHoraReg y fechaHoraVenci.
 */

let agenda;

function insertar() {
    let materia = (document.getElementById("txtMateria").value);
    let actiTitulo = (document.getElementById("txtActiTitulo").value);
    let actiDes = (document.getElementById("txtActiDes").value);
    let fechaHoraReg = (document.getElementById("txtFechaHoraReg").value);
    let fechaHoraVenci = (document.getElementById("txtFechaHoraVenci").value);

    let agenda =JSON.stringify({materia: materia, actiTitulo: actiTitulo, actiDes: actiDes,
        fechaHoraReg: fechaHoraReg, fechaHoraVenci: fechaHoraVenci}) ;    
    let parametros = new URLSearchParams({datos: agenda});
    fetch('api/agenda/insert',
            {
                method: 'POST',
                body: (parametros),
                headers: {'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'}
            }).then(response => response.json())
            .then(data => {
                Swal.fire('Actividad insertada correctamente', '', "success");               
            });
}
function catalogoGraduacion() {
    let datos = {};
    let parametros = new URLSearchParams({datos});

    fetch("api/agenda/getAllG", {
        method: 'POST',
        body: (parametros),
        headers: {'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'}
    }).then(response => response.json())
            .then(data => {
                if (data.error) {
                    alert(data.error);
                } else {
                    cargarTablaA(data);
                }
            });
}
function cargarTablaA(data) {
    agenda = data;
    let contenidoTG = "";
    for (var i = 0; i < agenda.length; i++) {
        contenidoTG += "<tr>";
        let titulo = agenda[i].actiTitulo;
        contenidoTG += "<td>" + titulo + "</td>";
        let descripcion = agenda[i].actiDes;
        contenidoTG += "<td>" + descripcion + "</td>";
        contenidoTG += "<td><button onclick='cargarFrmG(" + i + ");'>Ver</button></td>";
        contenidoTG += "</tr>";
        
    }
    
    document.getElementById("tbAgenda").innerHTML = contenidoTG;
}
function cargarFrmG(i) {
      document.getElementById("txtMateria").value = agenda[i].materia;
      document.getElementById("txtActiTitulo").value = agenda[i].actiTitulo;
      document.getElementById("txtActiDes").value = agenda[i].actiDes;
      document.getElementById("txtFechaHoraReg").value = agenda[i].fechaHoraReg;
      document.getElementById("txtFechaHoraVenci").value = agenda[i].fechaHoraVenci;
      document.getElementById("txtIdGraduacion").value = agenda[i].idAgenda;
}
