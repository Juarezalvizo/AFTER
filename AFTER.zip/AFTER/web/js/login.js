/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/JavaScript.js to edit this template
 */

function loginn()
{
    window.location.replace("http://localhost:8080/AFTER/principal.html");
}
function logout()
{
    window.location.replace('http://localhost:8080/OpticaQualite_v2/');
}

//// <script>
//// JavaScript
//const botonIngresar = document.getElementById('btnIngresar');
//
//botonIngresar.addEventListener('click', function() {//
////  window.location.href = ';
////});
//</script>
